package com.example.sqlitetask.Model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
class Usermodel(
    var name: String,
    var mobilenumber: String?,
    var email: String?,
    var gender: String?,
    var address: String?
) : Parcelable

