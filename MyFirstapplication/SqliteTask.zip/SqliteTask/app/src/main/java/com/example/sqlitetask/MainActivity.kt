package com.example.sqlitetask

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.sqlitetask.DbHelper.DBHelper
import com.example.sqlitetask.Model.Usermodel
import com.example.sqlitetask.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DBHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        dbHelper=DBHelper(this)
      //  Log.e("dataCount-->",""+dbHelper.getAllUserData().count)
        binding.insertUserrdataBtn.setOnClickListener{
            insertUserData()
        }

    }

    private fun insertUserData() {
        binding.apply {

                val enterUserName = enterUsernameMain.editText?.text?.toString()
                val enterMobileNumber = enterMobileNoMain.editText?.text?.toString()
                val enterEmailAdress = enterEmailMain.editText?.text?.toString()
                val enterAdress = enterAdressMain.editText?.text?.toString()
                val selectOption: Int = radiogroup.checkedRadioButtonId
                var genderselect = ""
                if(radiofemale.isChecked){
                    genderselect="Female"
                }else{
                    genderselect="Male"
                }
                enterUsernameMain.error = null
                enterMobileNoMain.error = null
                enterEmailMain.error = null
                enterAdressMain.error = null
                if (enterUserName!!.isEmpty()) {
                    enterUsernameMain.error = getString(R.string.enterusernameerro)
                } else if (enterMobileNumber!!.isEmpty()) {
                    enterMobileNoMain.error = getString(R.string.emailerro)
                } else if (enterEmailAdress!!.isEmpty()) {
                    enterEmailMain.error = getString(R.string.emailerro)
                } else if (enterAdress!!.isEmpty()) {
                    enterAdressMain.error = getString(R.string.adresserro)
                }
                else {
                    var add = dbHelper.addUserdata(
                        Usermodel(
                            enterUserName,
                            enterMobileNumber,
                            enterEmailAdress,
                            genderselect,
                            enterAdress
                        )
                    )
                    if(add>0){
                        Toast.makeText(this@MainActivity, R.string.insert_user_data, Toast.LENGTH_SHORT)
                            .show()
                        Log.e("dataCount-->",""+dbHelper.getAllUserData().count)
                    }
                }

            }

    }
}
