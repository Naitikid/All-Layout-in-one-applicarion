package com.example.sqlitetask.DbHelper

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.sqlitetask.ConstFile.*
import com.example.sqlitetask.Model.Usermodel

class DBHelper(private var context: Context) :SQLiteOpenHelper(context, DATABASE_NAME,null, 3) {

    override fun onCreate(db: SQLiteDatabase?) {
        var query = ("CREATE TABLE $TABLENAME($USERID INTEGER PRIMARY KEY AUTOINCREMENT,$NAME TEXT,$MOBILENUMBER TEXT,$EMAIL TEXT,$GENDER TEXT,$ADDRESS TEXT )")
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
    /*    db?.execSQL("DROP TABLE IF EXISTS" + TABLENAME)
        onCreate(db)*/
    }

    fun addUserdata(model: Usermodel): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(NAME, model.name)
        contentValues.put(MOBILENUMBER, model.mobilenumber)
        contentValues.put(EMAIL, model.email)
        contentValues.put(GENDER, model.gender)
        contentValues.put(ADDRESS, model.address)
        val userInsert = db.insert(TABLENAME, null, contentValues)

        db.close()
        return userInsert
    }
     fun getAllUserData():Cursor{
      var db=this.readableDatabase
        var cursor=db.rawQuery("SELECT *  FROM $TABLENAME",null)

        return cursor
        }
}

