package com.example.sqlitetask.ConstFile

const val   emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
const val DATABASE_NAME="my_Db"
const val USERID="userid"
const val TABLENAME="tablename"
const val NAME="name"
const val MOBILENUMBER="Mobilenumber"
const val EMAIL="Email"
const val GENDER="Gender"
const val ADDRESS="Address"
